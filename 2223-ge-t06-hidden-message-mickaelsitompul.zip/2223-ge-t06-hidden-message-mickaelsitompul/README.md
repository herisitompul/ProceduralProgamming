# T06 Hidden Message (Function)

Pada tugas kali ini, anda diminta untuk me-reproduce ```M01``` dengan melakukan dekomposisi dan pendistribusian instruksi ke dalam fungsi. Anda diberi kebebasan dalam mendekomposisi serta mengidentifikasi potensi pengembangan fungsi lengkap dengan berbagai karakteristik yang melekat dengannya (return type, dan parameters).


## Reporting

Presentasikan pekerjaan anda dalam sebuah video. Pada presentasi:
1. Jabarkan fungsi apa saya yang anda identifikasi serta tujuan pengembangannya.
2. Jabarkan karateristik dari fungsi yang anda identifikasi, mengapa tipe data dan parameternya demikian?

**Note**: Semakin tajam argumen dan penjabaran anda semakin mudah penilaian dilakukan.

**Kriteria video presentasi**:
+ 1080p/30fps, min. 10 menit.
+ Suara jernih dan dapat dengan jelas terdengar.
+ Posting video anda di YouTube, di-set "Not For Kids" dengan visibility Unlisted.

## Submissions:

1. t06_01.c
2. changelog.txt

## How to submit?
Please see https://youtu.be/g0BQ195-aWo
